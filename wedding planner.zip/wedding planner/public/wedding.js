document.getElementById("toggleLogin").addEventListener("click", function (event) {
    event.preventDefault();
    toggleForms();
});


document.getElementById("toggleSignup").addEventListener("click", function (event) {
    event.preventDefault();
    toggleForms();
});

function toggleForms() {
    document.querySelector('.login').classList.toggle("hidden");
    document.querySelector('.signup').classList.toggle("hidden");

}

document.getElementById("signupForm").addEventListener("submit", function (event) {
    event.preventDefault();

    // Retrieve form values
    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("pswd").value;
    const phone = document.getElementById("phone").value;

    // Send form data to server
    fetch('/signup', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, email, password, phone })
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.text();
        })
        .then(data => {
            alert(data);
        })
        .catch(error => {
            console.error('Error:', error);
        });

});

document.getElementById("loginForm").addEventListener("submit", function (event) {
    event.preventDefault();
    const email = document.getElementById("loginemail").value;
    const password = document.getElementById("loginpassword").value;

    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
    })
        .then(response => response.text())
        .then(data => {
            alert(data);
            if (data === 'Login successful') {
                window.location.assign('/website.html');

                // alert(succesfulylogin)
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
});

