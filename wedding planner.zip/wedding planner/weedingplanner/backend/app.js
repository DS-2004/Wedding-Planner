// Import required modules
const express = require('express');
const mysql = require('mysql');
const cors = require('cors');


// Create Express application
const app = express();
const port = process.env.PORT || 3000; // Set port number

// Middleware to parse JSON bodies
app.use(express.json());

// MySQL Connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'your_mysql_username',
  password: 'your_mysql_password',
  database: 'your_database_name'
});

// Connect to MySQL
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL: ' + err.stack);
    return;
  }
  console.log('Connected to MySQL as id ' + connection.threadId);
});

// Routes
// Sample GET request
app.get('/', (req, res) => {
  res.send('Hello World!');
});

// Sample POST request
app.post('/api/data', (req, res) => {
  // Access request body
  const { data } = req.body;
  
  // Perform database operations
  // Example: Insert data into MySQL
  const query = 'INSERT INTO your_table_name (column_name) VALUES (?)';
  connection.query(query, [data], (error, results, fields) => {
    if (error) {
      console.error('Error executing query: ' + error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    res.status(201).json({ message: 'Data inserted successfully' });
  });
});

// Start server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
