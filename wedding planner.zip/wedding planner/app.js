// const express = require('express');
// const mysql = require('mysql');
// const bodyParser = require('body-parser');
// const path = require('path'); // Add path module

// const app = express();

// // Create connection pool to MySQL database
// const connection = mysql.createPool({
//     connectionLimit: 10, // Adjust as needed
//     host: 'localhost', // Change to your MySQL server hostname
//     user: 'root', // Change to your MySQL username
//     password: '', // Change to your MySQL password
//     database: 'weddingplanner' // Change to your MySQL database name
// });

// // Middleware to parse request bodies
// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(bodyParser.json());

// // Route to handle sign-up request
// app.post('/signup', (req, res) => {
//     const { username, email, password, phone } = req.body; // parse form data

//     // Print signup details to console
//     console.log('Signup details:');
//     console.log('Username:', username);
//     console.log('Email:', email);
//     console.log('Password:', password);
//     console.log('Number:', phone);

//     // Insert user data into database
//     const sql = 'INSERT INTO users (username, email, password, phone) VALUES (?, ?, ?, ?)';
//     connection.query(sql, [username, email, password, phone], (error, result) => {
//         if (error) {
//             console.error('Error signing up:', error);
//             res.status(500).send('Error signing up');
//             return;
//         }
//         console.log('User signed up successfully');
//         res.send('User signed up successfully');
//     });
// });

// // Route to handle login request
// app.post('/login', (req, res) => {
//     const { email, password } = req.body;
//     console.log('email:', email);
//     console.log('password:', password);
//     // Check credentials against database
//     const sql = 'SELECT * FROM users WHERE email = ? AND password = ?';
//     connection.query(sql, [email, password], (error, results) => {
//         if (error) {
//             console.error('Error executing query:', error);
//             res.status(500).send('Error logging in');
//             return;
//         }
//         if (results.length > 0) {
//             res.send('Login successful');
//         } else {
//             res.status(401).send('Invalid credentials');
//         }
//     });
// });

// // Route to serve the about page
// app.get('/website', (req, res) => {
//     res.sendFile(path.join(__dirname, 'public', 'website.html'));
// });

// // Serve the HTML page
// app.use(express.static('public'));

// const PORT = process.env.PORT || 5005;
// app.listen(PORT, () => {
//     console.log(`Server is running on port ${PORT}`);
// });


const express = require('express');
const mysql = require('mysql');
// const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path'); // Add path module

const app = express();
// app.use(cors());


// Create connection pool to MySQL database
const connection = mysql.createPool({
    connectionLimit: 10, // Adjust as needed
    host: 'localhost', // Change to your MySQL server hostname
    user: 'root', // Change to your MySQL username
    password: '', // Change to your MySQL password
    database: 'weddingplanner' // Change to your MySQL database name
});

// Middleware to parse request bodies
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Route to handle sign-up request
app.post('/signup', (req, res) => {
    console.log("Server turned on");
    const { username, email, password, phone } = req.body; // parse form data

    // Insert user data into database
    const sql = 'INSERT INTO users (username, email, password, phone) VALUES (?, ?, ?, ?)';
    connection.query(sql, [username, email, password, phone], (error, result) => {
        if (error) {
            console.error('Error signing up:', error);
            res.status(500).send('Error signing up');
            return;
        }
        console.log('User signed up successfully');
        res.send('User signed up successfully');

    });
});


// Route to handle login request
app.post('/login', (req, res) => {
    const { email, password } = req.body;

    // Check credentials against database
    const sql = 'SELECT * FROM users WHERE email = ? AND password = ?';
    connection.query(sql, [email, password], (error, results) => {
        if (error) {
            console.error('Error executing query:', error);
            res.status(500).send('Error logging in');
            return;
        }
        if (results.length > 0) {
            res.send('Login successful');
           
        } else {
            res.status(401).send('Invalid credentials');
          
        }
    });
});

// Route to serve the about page
app.get('/website', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'website.html'));
});

// Serve the HTML page
app.use(express.static('public'));

const PORT = process.env.PORT || 5501;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

