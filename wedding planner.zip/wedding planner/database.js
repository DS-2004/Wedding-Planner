const express = require('express');
const app = express();

// app.use(express.static('public'));

// app.get('/', (req, res) => {
//     res.sendFile(__dirname + '/public/index.html');
// });

// Define more routes as needed

const {
    createPool
} = require('mysql');

const pool = createPool({
    host:"localhost",
    user:"root",
    password:"",
    database:"wedding planner",
    connectionLimit: 10
})
pool .query('select * from `user info`',(err, result, fields)=>{
    if(err) {
        return console.log(err);
    }
    return console.log(result);
})
//  app.listen(port, () =>  {
//     console.log('database listening at http://localhost:${port}');
//  });

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});


//  app.use(express.static('public'));